# Lazy Programming
**Identifier:** `lazy`

This assignment depends on the following libraries:
- `150basis`
- `stream`
