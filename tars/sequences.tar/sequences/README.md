# Sequences
**Identifier:** `sequences`

This assignment depends on the following libraries:
- `150basis`
- `sequence`
