# Datatypes Lab
**Identifier:** `datatypes_lab`

This assignment depends on the `150basis` library.
