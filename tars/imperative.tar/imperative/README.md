# Imperative Programming
**Identifier:** `imperative`

This assignment depends on the `150basis` library.
