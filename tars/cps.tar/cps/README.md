# Continuation Passing Style
**Identifier:** `cps`

This assignment depends on the `150basis` library.
